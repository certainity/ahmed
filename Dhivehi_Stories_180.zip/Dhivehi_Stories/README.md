# Dhivehi Stories (180) — by Kiyavama

Each .docx holds one story: the Dhivehi text page by page (the real story), and under every page an English image prompt you can paste into ChatGPT / DALL·E to draw that page. A character sheet at the top keeps the characters consistent across images.

Dhivehi is set in the Faruma font. If Faruma is not installed, Word falls back to MV Boli; install Faruma for the intended look.

30 stories per age folder. Adult (18+) stories are 10–12 scenes and 2,000–4,400 Dhivehi words each. No story contains fanditha, sihuru or black magic.

## Contents

### All Ages

- `01_honest_yoosuf.docx` — Honest Yoosuf (ތެދުވެރި ޔޫސުފް) — Islamic values / moral (honesty) — 11 pages
- `02_fathuns_first_fast.docx` — Fathun's First Fast (ފާތުންގެ ފުރަތަމަ ރޯދަ) — Islamic values (Ramadan, patience, sharing) — 11 pages
- `03_grandpas_coconut_palm.docx` — Grandpa's Coconut Palm (ކާފަގެ ރުއް) — Educational (Maldivian nature and tradition) — 11 pages
- `04_mariyam_and_the_turtles.docx` — Mariyam and the Turtles (މަރިޔަމާއި ވެލާ) — Kindness to animals / nature (environment) — 11 pages
- `05_zains_kite.docx` — Zain's Kite (ޒައިންގެ ގުޑި) — Gentle adventure — 11 pages
- `06_four_friends_clean_the_beach.docx` — Four Friends Clean the Beach (ހަތަރު އެކުވެރިން ގޮނޑުދޮށް ސާފުކުރި ދުވަސް) — Teamwork / environment — 11 pages
- `07_fishing_trip_with_father.docx` — Fishing Trip with Father (ބައްޕައާއެކު މަހަށް) — Family / patience — 11 pages
- `08_hasans_bicycle.docx` — Hasan's Bicycle (ހަސަންގެ ބައިސްކަލް) — Generosity / friendship — 11 pages
- `09_iftar_with_the_neighbour.docx` — Iftar with the Neighbour (އަވައްޓެރިޔާއާއެކު ރޯދަ ވީއްލުން) — Islamic values / community — 11 pages
- `10_grandfathers_old_days.docx` — Grandfather's Old Days (ކާފަގެ ކުރީގެ ދުވަސްތައް) — Heritage / educational — 11 pages
- `11_waves_and_tides.docx` — Waves and Tides (ރާޅާއި ދިޔަވަރު) — Educational (science of the sea) — 11 pages
- `12_the_lost_kitten.docx` — The Lost Kitten (ގެއްލުނު ބުޅާ ކުއްޖާ) — Kindness to animals — 11 pages
- `13_the_eid_dress.docx` — The Eid Dress (އީދު ހެދުން) — Islamic values / charity — 11 pages
- `14_first_day_at_school.docx` — First Day at School (ސްކޫލުގެ ފުރަތަމަ ދުވަސް) — Courage / friendship — 11 pages
- `15_mothers_garden.docx` — Mother's Garden (މަންމަގެ ބަގީޗާ) — Patience / nature — 11 pages
- `16_learning_to_swim.docx` — Learning to Swim (ފަތަން ދަސްކުރުން) — Perseverance — 11 pages
- `17_the_big_wave.docx` — The Big Wave (ބޮޑު ރާޅު) — Safety / obeying elders — 11 pages
- `18_the_baby_turtle.docx` — The Baby Turtle (ވެލާ ކުއްޖާގެ ދަތުރު) — Nature / educational — 11 pages
- `19_grateful_ali.docx` — Grateful Ali (ޝުކުރުވެރި ޢަލީ) — Islamic values (gratitude) — 11 pages
- `20_the_island_library.docx` — The Island Library (ރަށުގެ ލައިބްރަރީ) — Educational (love of reading) — 11 pages
- `21_grandmothers_raivaru_book.docx` — Grandmother's Raivaru Book (މާމަގެ ރައިވަރު ފޮތް) — Educational (heritage, Dhivehi poetry) — 11 pages
- `22_friday_at_the_mosque.docx` — Friday at the Mosque (ހުކުރު ދުވަސް) — Islamic values (family, Friday routine) — 11 pages
- `23_the_broken_window.docx` — The Broken Window (ތެޅުނު ބިއްލޫރިގަނޑު) — Moral (honesty, courage) — 11 pages
- `24_the_windy_day.docx` — The Windy Day (ވައިގަދަ ދުވަސް) — Fun / gentle adventure — 11 pages
- `25_the_lighthouse_keepers_daughter.docx` — The Lighthouse Keeper's Daughter (ބައްތި ބަލަހައްޓާ މީހާގެ ދަރިފުޅު) — Responsibility / courage — 11 pages
- `26_making_coconut_oil.docx` — Making Coconut Oil (ކާށި ތެޔޮ ހެދުން) — Educational (tradition, how things are made) — 11 pages
- `27_going_to_the_doctor.docx` — Going to the Doctor (ޑޮކްޓަރަށް ދައްކަން) — Health / courage — 11 pages
- `28_counting_the_stars.docx` — Counting the Stars (ތަރިތައް ގުނުން) — Islamic values (wonder at creation) / educational — 11 pages
- `29_the_stormy_night.docx` — The Stormy Night (ވިއްސާރަ ރޭ) — Community / helping each other — 11 pages
- `30_a_friend_from_another_island.docx` — A Friend from Another Island (އެހެން ރަށެއްގެ ރައްޓެއްސެއް) — Inclusion / friendship — 11 pages

### Age 3 to 5

- `01_one_two_three_fish.docx` — One, Two, Three Fish (އެކެއް ދޭއް ތިނެއް) — Educational (counting 1–5, colours, sea life) — 9 pages
- `02_aishas_colours.docx` — Aisha's Colours (އައިޝާގެ ކުލަތައް) — Educational (colours, island nature) — 9 pages
- `03_ali_goes_to_the_mosque.docx` — Ali Goes to the Mosque (އަލީ މިސްކިތަށް) — Islamic values (salah, wudu, mosque manners) — 9 pages
- `04_ahmeds_mango.docx` — Ahmed's Mango (އަހުމަދުގެ އަނބު) — Moral (sharing) — 9 pages
- `05_the_little_crab.docx` — The Little Crab (ކުޑަ ކަކުނި) — Gentle adventure (sea life) — 9 pages
- `06_babas_dhoni.docx` — Baba's Dhoni (ބައްޕަގެ ދޯނި) — Educational (colours) — 10 pages
- `07_the_little_chick.docx` — The Little Chick (ކުޑަ ފިޔޮއް) — Gentle adventure (animals) — 9 pages
- `08_morning_prayer_with_grandpa.docx` — Morning Prayer with Grandpa (ކާފައާއެކު ފަތިސް ނަމާދަށް) — Islamic values (salah routine) — 9 pages
- `09_the_moon.docx` — The Moon (ހަނދު) — Educational (moon phases) — 10 pages
- `10_say_bismillah.docx` — Say Bismillah (ބިސްމި ކިޔާށެވެ) — Islamic values (manners) — 10 pages
- `11_fishing_with_grandpa.docx` — Fishing with Grandpa (ކާފައާއެކު މަހަށް) — Educational (counting 1–5) — 10 pages
- `12_rainy_day.docx` — Rainy Day (ވިއްސާރަ ދުވަސް) — Gentle adventure (weather) — 9 pages
- `13_kitten_and_the_ball.docx` — The Kitten and the Ball (ކުޑަ ބުޅަލާއި ރޮދި ބޯޅަ) — Gentle adventure (animals) — 10 pages
- `14_the_tall_palm.docx` — The Tall Palm (ދިގު ރުއް) — Educational (opposites) — 9 pages
- `15_helping_in_mummys_kitchen.docx` — Helping in Mummy's Kitchen (މަންމަގެ ބަދިގޭގައި) — Educational (tastes and smells) — 10 pages
- `16_the_butterfly.docx` — The Butterfly (ކޮކާ) — Educational (colours) — 9 pages
- `17_eid_morning.docx` — Eid Morning (ޢީދު ހެނދުނު) — Islamic values (Eid) — 9 pages
- `18_bedtime_dua.docx` — Bedtime Dua (ނިދުމުގެ ކުރިން) — Islamic values (bedtime routine) — 9 pages
- `19_five_senses_at_the_beach.docx` — Zaina at the Beach (ގޮނޑުދޮށުގައި ޒައިނާ) — Educational (five senses) — 9 pages
- `20_washing_hands.docx` — Washing Hands (އަތް ދޮންނަން) — Educational (hygiene) — 9 pages
- `21_the_little_bird_learns_to_fly.docx` — The Little Bird Learns to Fly (ކުޑަ ދޫނި އުދުހެން ދަސްކުރުން) — Gentle adventure (nature, trying again) — 9 pages
- `22_the_red_ball.docx` — The Red Ball (ރަތް ބޯޅަ) — Moral (sharing) — 9 pages
- `23_saying_thank_you.docx` — Thank You (ޝުކުރިއްޔާ) — Moral / manners — 9 pages
- `24_planting_a_seed.docx` — Planting a Seed (އޮށެއް އިންދުން) — Educational (nature, patience) — 9 pages
- `25_the_crab_and_the_shell.docx` — The Hermit Crab and the Shell (ކަކުންޏާއި ބޮލި) — Gentle adventure (sea life, home) — 9 pages
- `26_my_first_tricycle.docx` — My First Tricycle (އަހަރެންގެ ފުރަތަމަ ބައިސްކަލު) — Gentle adventure (trying, courage) — 9 pages
- `27_brushing_teeth.docx` — Brushing Teeth (ދަތް އުނގުޅުން) — Educational (hygiene) — 9 pages
- `28_grandpas_night_stories.docx` — Grandpa's Night Stories (ކާފަގެ ރޭގަނޑު ވާހަކަތައް) — Family / imagination — 9 pages
- `29_lost_teddy.docx` — Lost Teddy (ގެއްލުނު ބެއާ) — Gentle adventure (feelings, helping) — 9 pages
- `30_big_and_small.docx` — Big and Small (ބޮޑު އަދި ކުޑަ) — Educational (opposites) — 9 pages

### Age 6 to 8

- `01_honest_shifa.docx` — Honest Shifa (ތެދުވެރި ޝިފާ) — Islamic values / moral (honesty) — 11 pages
- `02_nails_first_fast.docx` — Nail's First Fast (ނާއިލްގެ ފުރަތަމަ ރޯދަ) — Islamic values (Ramadan, patience) — 11 pages
- `03_grandpas_coral_mosque.docx` — Grandpa's Coral Stone Mosque (ކާފަގެ ހިރިގަލު މިސްކިތް) — Educational (Maldivian heritage) — 11 pages
- `04_leen_and_the_plastic_bag.docx` — Leen and the Plastic Bag (ލީންއާއި ޕްލާސްޓިކް ކޮތަޅު) — Educational (environment / marine life) — 11 pages
- `05_yamin_and_the_manta.docx` — Yamin and the Manta Ray (ޔާމިންއާއި މަޑި) — Adventure / educational (marine science) — 11 pages
- `06_the_reef_project.docx` — Reema's Reef Project (ރީމާގެ ފަރު މަޝްރޫޢު) — Educational (marine science / house reef) — 11 pages
- `07_the_homework_lie.docx` — Ziyad's Lie (ޒިޔާދުގެ ދޮގު) — Moral (honesty) — 11 pages
- `08_the_stranded_dolphin.docx` — The Stranded Dolphin (ގޮނޑުދޮށަށް ލެއްގި ކޯމަސް) — Kindness to animals / adventure — 11 pages
- `09_the_ramadan_lantern.docx` — The Ramadan Lantern (ރޯދަމަހުގެ ފާނޫޒު) — Islamic values (Ramadan, neighbours, sharing) — 11 pages
- `10_grandfathers_radio.docx` — Grandfather's Radio (ކާފަގެ ރޭޑިއޯ) — Educational (weather, safety) / family — 11 pages
- `11_the_night_the_power_went_out.docx` — The Night the Power Went Out (ކަރަންޓު ކެނޑުނު ރޭ) — Family / gratitude — 11 pages
- `12_learning_the_qaida.docx` — Zayan Learns the Qaida (ޒަޔާން ޤާއިދާ ދަސްކުރުން) — Islamic values (perseverance, learning) — 11 pages
- `13_fair_play.docx` — Fair Play (ތެދުވެރި ކުޅުން) — Moral (honesty in sport) — 11 pages
- `14_class_trip_to_male.docx` — Nahidha's Trip to Malé (ނާހިދާގެ މާލެ ދަތުރު) — Educational (Malé, national landmarks) — 11 pages
- `15_a_new_baby_sister.docx` — Rauf's Baby Sister (ރައުފްގެ ކޮއްކޮ) — Family / emotions — 11 pages
- `16_the_broken_net.docx` — The Broken Net (ވީދުނު ދާ) — Family / patience / tradition — 11 pages
- `17_the_kind_teacher.docx` — The Kind Teacher (އޯގާތެރި ޓީޗަރު) — Educational / kindness / reading — 11 pages
- `18_afraid_of_the_dark.docx` — Shaya and the Dark (ޝާޔާއާއި އަނދިރިކަން) — Islamic values (dua, courage) / emotions — 11 pages
- `19_collecting_shells.docx` — Collecting Shells (ބޮލި ހޮވުން) — Educational / nature (respect for living things) — 11 pages
- `20_the_bodu_beru_drum.docx` — The Bodu Beru Drum (ބޮޑުބެރު) — Cultural / educational (Maldivian music, patience) — 11 pages
- `21_the_dhoni_race.docx` — The Dhoni Race (ދޯނި ރޭސް) — Sports / moral (sportsmanship) — 11 pages
- `22_the_found_phone.docx` — The Found Phone (ފެނުނު ފޯނު) — Islamic values / moral (honesty, returning lost property) — 11 pages
- `23_helping_the_old_neighbour.docx` — Helping the Old Neighbour (ކައިރީގައި އުޅޭ މާމަ) — Islamic values / moral (kindness to neighbours, respect for elders) — 11 pages
- `24_cleaning_the_mosque.docx` — Cleaning the Mosque (މިސްކިތް ސާފުކުރުން) — Islamic values (service, cleanliness, teamwork) — 11 pages
- `25_turtle_rescue.docx` — Turtle Rescue (ވެލާ ސަލާމަތްކުރުން) — Adventure / environment (compassion for animals) — 11 pages
- `26_the_kite_competition.docx` — The Kite Competition (ގުޑި މުބާރާތް) — Moral (generosity, friendship) — 11 pages
- `27_dua_for_grandmother.docx` — Dua for Grandmother (މާމައަށް ދުޢާ) — Islamic values (dua, patience, trust in Allah, family) — 11 pages
- `28_the_rainwater_tank.docx` — The Rainwater Tank (ވާރޭފެން ތާނގީ) — Educational (water, environment, gratitude) — 11 pages
- `29_plastic_free_picnic.docx` — Plastic-Free Picnic (ޕްލާސްޓިކް ނެތް ދަތުރު) — Educational / environment (reducing plastic, teamwork) — 11 pages
- `30_the_coconut_crab.docx` — The Coconut Crab (ކަކުނި ބޮންޑާ) — Educational / nature (curiosity, respect for wildlife) — 11 pages

### Age 9 to 12

- `01_the_lost_dhoni.docx` — The Lost Dhoni (ގެއްލުނު ދޯނި) — Adventure — 16 pages
- `02_the_map_in_grandmas_chest.docx` — The Map in Grandma's Chest (މާމަގެ ފޮށީގެ ޗާޓު) — Adventure — 16 pages
- `03_the_missing_library_book.docx` — The Missing Library Book (ލައިބްރަރީގެ ގެއްލުނު ފޮތް) — Mystery — 14 pages
- `04_alis_secret_charity.docx` — Ali's Secret Charity (ޢަލީގެ ސިއްރު ޞަދަޤާތް) — Islamic values (charity, honesty with parents) — 14 pages
- `05_habeebs_journey_to_utheemu.docx` — Habeeb's Journey to Utheemu (ހަބީބުގެ އުތީމު ދަތުރު) — Educational / historical fiction (courage) — 15 pages
- `06_the_storm_shelter.docx` — The Storm Shelter (ތޫފާނުގެ ހިޔާވަހި) — Community / responsibility — 14 pages
- `07_the_hidden_cave.docx` — The Hidden Cave (ފޮރުވިފައިވާ ހޮހަޅަ) — Adventure — 14 pages
- `08_rival_teams.docx` — Rival Teams (ވާދަވެރި ދެ ޓީމު) — Moral (respect, sportsmanship) — 14 pages
- `09_coral_bleaching.docx` — The White Coral (ހުދުވި މުރަކަ) — Educational (marine science, environment) — 14 pages
- `10_the_time_capsule.docx` — The Time Capsule (ވަގުތުގެ ފޮށި) — Educational / friendship (history, memory) — 14 pages
- `11_the_old_well.docx` — The Secret of the Old Well (ބާ ވަޅުގެ ސިއްރު) — Mystery (safe explanation) — 14 pages
- `12_the_school_election.docx` — The School Election (ސްކޫލް އިންތިޚާބު) — Moral (integrity, honesty) — 14 pages
- `13_the_fishermans_debt.docx` — The Fisherman's Debt (މަސްވެރިޔާގެ ދަރަނި) — Moral / family (honesty, hard work) — 14 pages
- `14_online_safety.docx` — Behind the Screen (ސްކްރީނުގެ ފަހަތުގައި) — Safety / moral (online safety, trust in parents) — 13 pages
- `15_the_lake_on_fuvahmulah.docx` — The Lake on Fuvahmulah (ފުވައްމުލަކުގެ ކުޅި) — Adventure / educational (geography, nature) — 15 pages
- `16_the_lost_camera.docx` — The Lost Camera (ގެއްލުނު ކެމެރާ) — Mystery — 15 pages
- `17_night_fishing.docx` — Night Fishing (ރޭގަނޑުގެ މަސްވެރިކަން) — Adventure (first experiences, patience) — 15 pages
- `18_the_whale_shark.docx` — The Whale Shark (ފެހުރިހި) — Adventure / nature (respect for wildlife) — 14 pages
- `19_the_robotics_club.docx` — The Robotics Club (ރޮބޮޓިކްސް ކްލަބް) — Educational / STEM, teamwork — 15 pages
- `20_the_dry_season.docx` — The Dry Season (ހިކި މޫސުން) — Moral / social (fairness, sharing, community) — 14 pages
- `21_the_sandbank_picnic.docx` — The Sandbank Picnic (ފިނޮޅު ދަތުރު) — Adventure / safety — 14 pages
- `22_the_fake_friend.docx` — The Fake Friend (ހަގީގީ ރައްޓެހި) — Moral / social (true friendship, honesty) — 14 pages
- `23_the_new_student.docx` — The New Student (އާ ދަރިވަރު) — Moral / social (inclusion, kindness) — 14 pages
- `24_ramadan_night_market.docx` — Ramadan Night Market (ރޯދަ ބާޒާރުގެ ކުޑަ ފިހާރަ) — Islamic values (honesty, effort, charity) — 14 pages
- `25_grandfathers_dhoni_plans.docx` — Grandfather's Dhoni Plans (މުނިކާފަގެ އޮޑި ކުރެހުންތައް) — Educational / heritage (boatbuilding) — 14 pages
- `26_the_reef_guardians.docx` — The Reef Guardians (ފަރު ބަލަހައްޓާ ކުދިން) — Educational / environment (teamwork, leadership) — 14 pages
- `27_the_missing_coconuts.docx` — The Missing Coconuts (ގެއްލޭ ކާށިތައް) — Mystery — 14 pages
- `28_the_island_newspaper.docx` — The Island Newspaper (ރަށު ނޫސް) — Moral / educational (truth, responsibility, journalism) — 14 pages
- `29_the_hafiz_cousin.docx` — The Hafiz Cousin (ހާފިޒު ކަޒިން) — Islamic values (perseverance, humility, love of the Quran) — 13 pages
- `30_the_shipwreck_on_the_reef.docx` — The Shipwreck on the Reef (ފަރުމަތީ އޮތް ބޯޓު) — Adventure / educational (marine biology, history) — 15 pages

### Age 13 to 17

- `01_first_night_of_ramadan.docx` — The First Night of Ramadan (ރޯދަމަހުގެ ފުރަތަމަ ރޭ) — Islamic values / family — 8 pages
- `02_night_without_a_moon.docx` — The Night Without a Moon (ހަނދު ނުފެންނަ ރޭ) — Horror / folklore — 8 pages
- `03_the_back_seat.docx` — The Back Seat (ފަހަތު ގޮނޑި) — Moral / social (bullying) — 8 pages
- `04_three_days_adrift.docx` — Three Days Adrift (އޮޔާދިޔަ ތިން ދުވަސް) — Adventure / survival — 8 pages
- `05_coral_stone_mosque.docx` — The Coral Stone Mosque (ހިރިގަލުގެ މިސްކިތް) — Historical / educational fiction — 8 pages
- `06_first_job_at_the_resort.docx` — First Job at the Resort (ރިސޯޓުގައި ފުރަތަމަ ވަޒީފާ) — Moral / Islamic values (honesty, trust) — 9 pages
- `07_the_exam.docx` — The Exam (އިމްތިޙާން) — Moral (integrity under pressure) — 8 pages
- `08_the_offer.docx` — The Offer (ހުށަހެޅުން) — Social / moral (drugs, friendship, courage to say no) — 8 pages
- `09_she_wants_to_be_captain.docx` — She Wants to Be Captain (ކެޔޮޅަކަށް ވާން ބޭނުން) — Determination / family — 9 pages
- `10_moving_to_male.docx` — Moving to Malé (މާލެއަށް ބަދަލުވުން) — Family / change / belonging — 9 pages
- `11_the_rumour.docx` — The Rumour (އަޑު) — Social / responsibility (social media) — 9 pages
- `12_the_old_school_building.docx` — The Old School Building (ބާ ސްކޫލު ޢިމާރާތް) — Horror / folklore — 9 pages
- `13_the_ferry_in_the_storm.docx` — The Ferry in the Storm (ތޫފާނުގައި ފެރީ) — Adventure / survival — 8 pages
- `14_grandfather_forgets.docx` — Grandfather Forgets (ކާފަ ހަނދާން ނެތެނީ) — Family / patience / compassion — 8 pages
- `15_the_anger_inside.docx` — The Anger Inside (އެތެރޭގައި އޮތް ރުޅި) — Islamic values / self-control (patience) — 8 pages
- `16_the_quran_competition.docx` — The Quran Competition (ޤުރުއާން މުބާރާތް) — Islamic values / perseverance / humility — 8 pages
- `17_the_loan_shark.docx` — The Loan Shark (ދަރަނި) — Social / courage / family — 7 pages
- `18_the_rising_sea.docx` — The Rising Sea (އުފުލެމުންދާ ކަނޑު) — Educational / environment / civic action — 8 pages
- `19_the_brother_who_left.docx` — The Brother Who Left (ދިޔަ ބޭބެ) — Family / forgiveness — 8 pages
- `20_the_drowned_dhonis_bell.docx` — The Drowned Dhoni's Bell (ގެނބުނު ދޯނީގެ ރަނގަބީލު) — Horror / folklore — 8 pages
- `21_the_football_scholarship.docx` — The Football Scholarship (ފުޓުބޯޅަ ސްކޮލަރޝިޕް) — Sport / loyalty / moral — 8 pages
- `22_talking_to_the_counsellor.docx` — Talking to the Counsellor (ކައުންސެލަރާ ވާހަކަދެއްކުން) — Mental health / growing up — 8 pages
- `23_the_cyclone_shelter.docx` — The Cyclone Shelter (ތޫފާނުގެ ހިޔާވަހި) — Community / courage / adventure — 8 pages
- `24_the_portuguese_map.docx` — The Portuguese Map (ޕޯޗުގީޒުންގެ ޗާޓު) — Historical adventure — 8 pages
- `25_the_lie_that_grew.docx` — The Lie That Grew (ބޮޑުވި ދޮގު) — Moral / honesty — 8 pages
- `26_trust_at_sea.docx` — Trust at Sea (ކަނޑުމަތީގައި ވަކީލުކުރުން) — Islamic values / adventure (tawakkul, seamanship) — 9 pages
- `27_the_old_folks_home.docx` — The Old Folks' Home (މުސްކުޅިންގެ ހިޔާ) — Community / empathy / growing up — 8 pages
- `28_the_reef_cleanup_contest.docx` — The Reef Cleanup Contest (ފަރު ސާފުކުރުމުގެ މުބާރާތް) — Environment / rivalry / teamwork — 8 pages
- `29_the_night_dive.docx` — The Night Dive (ރޭގަނޑުގެ ފީނުން) — Adventure / survival / keeping calm — 8 pages
- `30_the_last_letter.docx` — The Last Letter (އެންމެ ފަހު ސިޓީ) — Family / grief / Eid — 8 pages

### Age 18 and above

- `01_the_day_the_wave_came.docx` — The Day the Wave Came (ރާޅު އައި ދުވަސް) — Survival / faith (2004 tsunami) — 11 pages
- `02_the_island_that_was_left.docx` — The Island That Was Left (ދޫކޮށްލި ރަށް) — Horror / psychological — 11 pages
- `03_fathers_bag.docx` — Father's Bag (ބައްޕަގެ ދަބަސް) — Social drama / repentance (drug addiction) — 11 pages
- `04_the_night_boat.docx` — The Night Boat (ރޭގަނޑުގެ އޮޑި) — Historical fiction (Portuguese occupation, 16th century) — 11 pages
- `05_the_fourth_floor.docx` — The Fourth Floor (ހަތަރުވަނަ ފަންގިފިލާ) — Mystery / thriller — 11 pages
- `06_ramadan_at_the_resort.docx` — Ramadan at the Resort (ރިސޯޓުގައި ރޯދަ) — Islamic values / family drama — 11 pages
- `07_the_delayed_proposal.docx` — The Delayed Proposal (ލަސްވި ކައިވެނި) — Social drama / romance (halal) — 11 pages
- `08_the_fishermans_last_catch.docx` — The Fisherman's Last Catch (ކެޔޮޅުގެ ފަހު މަސްވެރިކަން) — Drama / reflection on age and legacy — 11 pages
- `09_the_migrant_worker.docx` — The Migrant Worker (ރަފީޤުގެ ބައިސްކަލު) — Social drama / dignity and friendship — 11 pages
- `10_the_seamstress.docx` — The Seamstress (ފަހާ މީހާ) — Family drama / a mother's sacrifice — 11 pages
- `11_the_widows_shop.docx` — The Widow's Shop (ހައްވާގެ ފިހާރަ) — Social drama / resilience — 11 pages
- `12_the_council_file.docx` — The Council File (ކައުންސިލްގެ ފައިލު) — Moral drama / integrity — 11 pages
- `13_island_without_a_doctor.docx` — Island Without a Doctor (ޑޮކްޓަރެއް ނެތް ރަށް) — Drama / medical, one night — 11 pages
- `14_the_one_who_came_back.docx` — The One Who Came Back (އެނބުރި އައި މީހާ) — Drama / return and belonging — 11 pages
- `15_the_guesthouse.docx` — The Guesthouse (ގެސްޓްހައުސް) — Horror / folklore — 10 pages
- `16_the_thing_in_the_lagoon.docx` — The Thing in the Lagoon (ފަޅުތެރޭގައި އޮތް އެތި) — Horror / folklore — 10 pages
- `17_the_inheritance.docx` — The Inheritance (ތަރިކަ) — Family drama / justice — 10 pages
- `18_the_hajj_savings.docx` — The Hajj Savings (ޙައްޖު ފައިސާ) — Islamic values / sacrifice — 10 pages
- `19_twenty_years_after_the_wave.docx` — Twenty Years After the Wave (ރާޅަށް ވިހި އަހަރު) — Drama / faith / memory — 10 pages
- `20_the_man_who_forgave.docx` — The Man Who Forgave (މައާފްކުރި މީހާ) — Islamic values / family drama — 12 pages
- `21_night_shift.docx` — Night Shift (ރޭގަނޑު ޑިއުޓީ) — Drama / everyday heroism — 11 pages
- `22_the_atoll_teacher.docx` — The Atoll Teacher (އަތޮޅު ޓީޗަރު) — Drama / education / coming of age — 11 pages
- `23_after_the_divorce.docx` — After the Divorce (ވަރިއަށް ފަހު) — Family drama / values — 10 pages
- `24_the_smugglers_dhoni.docx` — The Smugglers' Dhoni (ވަގުންގެ ދޯނި) — Thriller / moral drama (1990s) — 10 pages
- `25_the_factory_strike.docx` — The Factory Strike (ފެކްޓަރީގެ ހަޅުތާލު) — Social drama / justice — 10 pages
- `26_the_well_at_midnight.docx` — The Well at Midnight (މެންދަމުގެ ވަޅު) — Horror / folklore — 12 pages
- `27_the_pilgrims_return.docx` — The Pilgrim's Return (ޙައްޖުން އެނބުރި އައުން) — Islamic values / family / change — 10 pages
- `28_the_sea_wall.docx` — The Sea Wall (ތޮށިގަނޑު) — Community drama / environment — 10 pages
- `29_the_last_toddy_tapper.docx` — The Last Toddy Tapper (އެންމެ ފަހު ރާވެރިޔާ) — Drama / heritage / fathers and sons — 10 pages
- `30_the_letter_in_the_quran.docx` — The Letter in the Quran (ޤުރުއާނުގެ ތެރޭގައި އޮތް ސިޓީ) — Mystery / family — 10 pages

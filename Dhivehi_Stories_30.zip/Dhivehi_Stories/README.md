# Dhivehi Stories (30) — by Kiyavama

Each .docx holds one story: the Dhivehi text page by page (the real story), and under every page an English image prompt you can paste into ChatGPT / DALL·E to draw that page. A character sheet at the top keeps the characters consistent across images.

Dhivehi is set in the Faruma font. If Faruma is not installed, Word falls back to MV Boli; install Faruma for the intended look.

## Contents


### All Ages

- `01_honest_yoosuf.docx` — Honest Yoosuf (ތެދުވެރި ޔޫސުފް) — Islamic values / moral (honesty) — 11 pages
- `02_fathuns_first_fast.docx` — Fathun's First Fast (ފާތުންގެ ފުރަތަމަ ރޯދަ) — Islamic values (Ramadan, patience, sharing) — 11 pages
- `03_grandpas_coconut_palm.docx` — Grandpa's Coconut Palm (ކާފަގެ ރުއް) — Educational (Maldivian nature and tradition) — 11 pages
- `04_mariyam_and_the_turtles.docx` — Mariyam and the Turtles (މަރިޔަމާއި ވެލާ) — Kindness to animals / nature (environment) — 11 pages
- `05_zains_kite.docx` — Zain's Kite (ޒައިންގެ ގުޑި) — Gentle adventure — 11 pages

### Age 3 to 5

- `01_one_two_three_fish.docx` — One, Two, Three Fish (އެކެއް ދޭއް ތިނެއް) — Educational (counting 1–5, colours, sea life) — 9 pages
- `02_aishas_colours.docx` — Aisha's Colours (އައިޝާގެ ކުލަތައް) — Educational (colours, island nature) — 9 pages
- `03_ali_goes_to_the_mosque.docx` — Ali Goes to the Mosque (އަލީ މިސްކިތަށް) — Islamic values (salah, wudu, mosque manners) — 9 pages
- `04_ahmeds_mango.docx` — Ahmed's Mango (އަހުމަދުގެ އަނބު) — Moral (sharing) — 9 pages
- `05_the_little_crab.docx` — The Little Crab (ކުޑަ ކަކުނި) — Gentle adventure (sea life) — 9 pages

### Age 6 to 8

- `01_honest_shifa.docx` — Honest Shifa (ތެދުވެރި ޝިފާ) — Islamic values / moral (honesty) — 11 pages
- `02_nails_first_fast.docx` — Nail's First Fast (ނާއިލްގެ ފުރަތަމަ ރޯދަ) — Islamic values (Ramadan, patience) — 11 pages
- `03_grandpas_coral_mosque.docx` — Grandpa's Coral Stone Mosque (ކާފަގެ ހިރިގަލު މިސްކިތް) — Educational (Maldivian heritage) — 11 pages
- `04_leen_and_the_plastic_bag.docx` — Leen and the Plastic Bag (ލީންއާއި ޕްލާސްޓިކް ކޮތަޅު) — Educational (environment / marine life) — 11 pages
- `05_yamin_and_the_manta.docx` — Yamin and the Manta Ray (ޔާމިންއާއި މަޑި) — Adventure / educational (marine science) — 11 pages

### Age 9 to 12

- `01_the_lost_dhoni.docx` — The Lost Dhoni (ގެއްލުނު ދޯނި) — Adventure — 16 pages
- `02_the_map_in_grandmas_chest.docx` — The Map in Grandma's Chest (މާމަގެ ފޮށީގެ ޗާޓު) — Adventure — 16 pages
- `03_the_missing_library_book.docx` — The Missing Library Book (ލައިބްރަރީގެ ގެއްލުނު ފޮތް) — Mystery — 14 pages
- `04_alis_secret_charity.docx` — Ali's Secret Charity (ޢަލީގެ ސިއްރު ޞަދަޤާތް) — Islamic values (charity, honesty with parents) — 14 pages
- `05_habeebs_journey_to_utheemu.docx` — Habeeb's Journey to Utheemu (ހަބީބުގެ އުތީމު ދަތުރު) — Educational / historical fiction (courage) — 15 pages

### Age 13 to 17

- `01_first_night_of_ramadan.docx` — The First Night of Ramadan (ރޯދަމަހުގެ ފުރަތަމަ ރޭ) — Islamic values / family — 8 pages
- `02_night_without_a_moon.docx` — The Night Without a Moon (ހަނދު ނުފެންނަ ރޭ) — Horror / folklore — 8 pages
- `03_the_back_seat.docx` — The Back Seat (ފަހަތު ގޮނޑި) — Moral / social (bullying) — 8 pages
- `04_three_days_adrift.docx` — Three Days Adrift (އޮޔާދިޔަ ތިން ދުވަސް) — Adventure / survival — 8 pages
- `05_coral_stone_mosque.docx` — The Coral Stone Mosque (ހިރިގަލުގެ މިސްކިތް) — Historical / educational fiction — 8 pages

### Age 18 and above

- `01_the_day_the_wave_came.docx` — The Day the Wave Came (ރާޅު އައި ދުވަސް) — Survival / faith (2004 tsunami) — 8 pages
- `02_the_fanditha_mans_island.docx` — The Fanditha Man's Island (ފަންޑިތަވެރިޔާގެ ރަށް) — Horror / folklore — 8 pages
- `03_fathers_bag.docx` — Father's Bag (ބައްޕަގެ ދަބަސް) — Social drama / repentance (drug addiction) — 8 pages
- `04_the_night_boat.docx` — The Night Boat (ރޭގަނޑުގެ އޮޑި) — Historical fiction (Portuguese occupation, 16th century) — 8 pages
- `05_the_fourth_floor.docx` — The Fourth Floor (ހަތަރުވަނަ ފަންގިފިލާ) — Mystery / thriller — 8 pages
